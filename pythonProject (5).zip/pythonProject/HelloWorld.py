print('HelloWorld')
a=10
b=3.4
c="hello"
print(a+b)

a1=[1,2,3,'klu',20.3,20.4,'dec']
a2={1,2,3,'klu',20.3,20.4,'dec'}
a3=(1,2,3,'klu',20.3,20.4,'dec')
a4={2200031535:'a',2200033161:'b'}
print(type(a1),type(a2),type(a3),type(a4))