numbers = [4, 7, 9, 12, 5]
average = sum(numbers) / len(numbers)
print("The average is:", average)