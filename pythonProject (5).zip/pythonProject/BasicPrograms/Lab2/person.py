class Person:
    def _init__(self,name,age):
       self.name = name
       self.age = age
    def __str__(self):
          return f"name {self.name} and age {self.age}"
p = Person("Avinash",19)

print(P)
