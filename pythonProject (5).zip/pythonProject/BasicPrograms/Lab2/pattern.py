x = int(input())
for i in range(0,x*2):
   if(i < x):
      print("*"*(i+1))
   else:
       print("*"*((x*2)-(i+1)))