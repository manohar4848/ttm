x = int(input())
y = int(input())
z = int(input())
if (x*x == y*y+z*z):
        print("right anagled triangle")
else:
        print("not a right anagled triangle")