import datetime
import time
import calendar
'''print(time.time())
print(time.asctime())

d=datetime.datetime.now()
print(d)
print(d.year)'''

s=calendar.prcal(2024)
s2=calendar.month(2024,1)
s1=calendar.isleap(2024)
print(s1)