while True:
    try:
        n=int(input("Enter an integer:"))
        m=int(input("Enter an integer:"))
        z=n/m
        break
    except Exception as e:
        print("not an integer!Please again 123")
        print(e)
    except ValueError:
        print("Not an integer!please again 456")
    finally:
        print("You have successfully enter integer")


