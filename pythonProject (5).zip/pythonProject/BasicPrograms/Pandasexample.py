import pandas as pd
data = {
    'Name': ['Alice', 'Bob', 'Charlie', 'David'],
    'Age': [25, 30, 22, 35],
    'Grade': [85, 92, 78, 88]
}
df = pd.DataFrame(data)
print("DataFrame:")
print(df)
print()
print("Basic Statistics:")
print(df.describe())
print()
print("Filtered Data:")
filtered_df = df[df['Age'] > 25]
print(filtered_df)
print()
df['Status'] = ['Pass' if grade >= 80 else 'Fail' for grade in df['Grade']]
print("Updated DataFrame:")
print(df)