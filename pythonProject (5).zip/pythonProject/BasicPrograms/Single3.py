from BasicPrograms.Single1 import c
from BasicPrograms.Single2 import p1
class p2(c,p1):
    def function(self):
        print("This is from p2")
obj2=p2()
obj2.function()
obj2.c1()
obj2.parentinfo()