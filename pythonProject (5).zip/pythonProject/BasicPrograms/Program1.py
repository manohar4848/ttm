#program 1
'''n=int(input("Enter a number:"))
if n==0:
    print("Wrong Number")
else:
  for i in range(n,n+1):
    val=n*(n*1)
    print(val)'''

#program 2
'''a=int(input())
for i in range(1,a+1):
    print(15,'*',i,'=',i*15)'''

#program 3
'''x=0
str="thisismycountry"
for i in str:
   x=x-1
   print(str[0:x])
for i in str:
   x=x+1
   print(str[0:x])
print(str[::-1])'''

#program 4
'''x=0
str='*****'
for i in str:
    x=x+1
    print(str[0:x])
for i in str:
    x=x-1
    print(str[0:x])'''

#program 5
'''
x=int(input("Enter a number:"))
fact=1
for i in range(1,x+1):
    fact=fact*i
print(fact)'''

