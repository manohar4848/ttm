'''import random
n=random.randbytes(5)
print(n)
print(random.randrange(10,300))

list1=["MSD","Sailesh","Dhanush"]
list2={"Virat","Ajith","Aditya"}
list3={"Cricketer":"Dhanush","Student":"Sailesh"}
list4=("Virat","Ajith","Aditya")
print(random.choice(list1))
#print(random.choice(list2))
#print(random.choice(list3))
print(random.choice(list4))'''
import string
import random
s=10
ran=''.join(random.sample(string.ascii_uppercase+string.digits,k=5))
s1=4
ran1=''.join(random.sample(string.digits,k=6))
print(ran)
print(ran1)