import datetime
x=datetime.datetime.now()
from datetime import timedelta
print(x+timedelta(days=+10))