class base1:
    def baseinfo(self):
        print("From base1")
class p1(base1):
    def parentinfo(self):
        print("From p1 class")
obj1=p1()
obj1.parentinfo()
obj1.baseinfo()