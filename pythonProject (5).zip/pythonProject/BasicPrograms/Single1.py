class c:
    def c1(self):
        print("From class c")