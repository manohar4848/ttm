try:
    klu1=open("file.txt","r+")
    try:
        klu1.write("My name is file.txt")
    finally:
        klu1.close()
except IOError:
    print("File not found")
else:
    print("The file opened successfully")
    klu1.close()