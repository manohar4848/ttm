z = input()
z1 = int(z)
print(z1)