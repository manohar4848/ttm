z = int(input())
A = float(z)
print(A)