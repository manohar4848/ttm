def Average(lis):
    return average
lis =[4,6,8,9,10,57]
average =  sum(lis)/len(lis)
print("avg is ",average)