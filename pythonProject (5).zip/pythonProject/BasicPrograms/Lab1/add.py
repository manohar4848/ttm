def my_function(a, b):
    print(a + b)

def my_func1(a, b):
    print(a + b)

def my_funct2(a, b):
    print(a + b)

def addcomplex(a1, b1, a2, b2):
    x1 = int(a1)
    x2 = int(b1)
    y1 = int(a2)
    y2 = int(b2)
    j = x1 + y1
    k = x2 + y2
    print(j, k)
    a = int(input())
    b = int(input())
my_function(2, 3)
my_func1(4, 5)
my_funct2(6, 7)
addcomplex(1, 2, 3, 4)
